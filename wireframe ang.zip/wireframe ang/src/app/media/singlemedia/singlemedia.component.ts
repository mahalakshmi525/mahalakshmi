import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-singlemedia',
  templateUrl: './singlemedia.component.html',
  //styleUrls: ['./singlemedia.component.css']
})
export class SinglemediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
