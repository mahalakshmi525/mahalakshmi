import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountupdate',
  templateUrl: './accountupdate.component.html',
  styleUrls: ['./accountupdate.component.css']
})
export class AccountupdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
