package com.pixogram.mediaplumbingservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.pixogram.mediaplumbingservice.feignproxy.MediaServiceProxy;
import com.pixogram.mediaplumbingservice.model.MediaData;
import com.pixogram.mediaplumbingservice.model.MediaDataModel;
import com.pixogram.mediaplumbingservice.model.MediaDetailsModel;
import com.pixogram.mediaplumbingservice.model.MediaModel;
import com.pixogram.mediaplumbingservice.response.GalleryDisplayResponse;




@RestController
public class MediaServicePlumbingController {
	
	@Autowired
	private MediaServiceProxy mediaServiceProxy;
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	//private final String MEDIA_URL ="http://localhost:4561/media-service/media";

	@PostMapping("/media")
	public void post(@RequestParam("file") MultipartFile file,
					@RequestParam("url") String url,
					@RequestParam("title") String title,
					@RequestParam("description") String description,
					@RequestParam("tags") String tags,
					@RequestParam("userid") String userid,
					@RequestParam("type") String type)
	{
		
		MediaDataModel model = new MediaDataModel(Integer.parseInt(userid),url,title,description,tags,type);
		
		this.mediaServiceProxy.saveData(model);
		
		this.mediaServiceProxy.save(file);
	
	}
	
	@GetMapping("/media/{userId}")
	public ResponseEntity<MediaDetailsModel> getAllById(@PathVariable Integer userId){
		ResponseEntity<MediaModel> media = this.mediaServiceProxy.getall(userId);
		List<GalleryDisplayResponse> filelist = new ArrayList<GalleryDisplayResponse>();
		
		logger.info("user id : => : "+userId);
		
		for(MediaData data : media.getBody().getMedialist()) {
						
			GalleryDisplayResponse response = new GalleryDisplayResponse(data.getId(), data.getUserId(), data.getTitle(), data.getDescription(), data.getTags(), data.getType(), data.getUrl());
			
			filelist.add(response);
		}
		
		MediaDetailsModel resultlist = new MediaDetailsModel();
		resultlist.setFilelist(filelist);
		ResponseEntity<MediaDetailsModel> result = new ResponseEntity<MediaDetailsModel>(resultlist,HttpStatus.OK);	
		
		return result;
	}
	

	
}

