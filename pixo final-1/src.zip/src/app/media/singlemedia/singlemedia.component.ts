import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
//import { MediaserviceService } from 'src/app/services/mediaservices/mediaservice.service';
import { Router } from '@angular/router';
import { Media } from 'src/app/model/media.model';
import { MediaserviceService } from 'src/app/services/mediaservice/mediaservice.service';

@Component({
  selector: 'app-singlemedia',
  templateUrl: './singlemedia.component.html',
  //styleUrls: ['./singlemedia.component.css']
})
export class SinglemediaComponent implements OnInit {
  description: String;
  myFormGroup: FormGroup;
  title: String;
  tags: String;
  file : any;
  selectedFiles: FileList;
  currentFileUpload: File;
  date:Date;

  constructor(formBuilder : FormBuilder,public mediaService : MediaserviceService,public router : Router) { 

    console.log("in form bilder of single media");
    this.myFormGroup=formBuilder.group({
     
      "title":new FormControl(""),
      "description": new FormControl(""),
      "tags":new FormControl("")
        
     });
  }
  onImageLoad(event){
    this.selectedFiles = event.target.files;
    this.currentFileUpload = this.selectedFiles.item(0);
  }
  
  singlemedia(){
   /* this.title= this.myFormGroup.controls['Title'].value;
    this.description=this.myFormGroup.controls['Description'].value;
    this.tags=this.myFormGroup.controls['Tags'].value;*/
    console.log("Single Media Details method");
    this.title= this.myFormGroup.controls['title'].value;
    this.description=this.myFormGroup.controls['description'].value;
    this.tags=this.myFormGroup.controls['tags'].value;
    this.date=new Date();
    let dateString = `_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
    if (this.currentFileUpload.type == 'image/png') {
      this.file = `${this.title}${dateString}.png`;
    }
    if (this.currentFileUpload.type == 'image/jpeg' || this.currentFileUpload.type == 'image/jpg') {
      this.file = `${this.title}${dateString}.jpeg`;
    }
  
    console.log(this.file+"\n"+this.title+"\n"+this.description+"\n"+this.tags);
    let uploadfile = new Media(this.file,this.title,this.description,this.tags)

    this.mediaService.pushFileToStorage(this.currentFileUpload,this.title,this.description,this.tags,this.file,this.currentFileUpload.type).subscribe(
      (responce)=>{this.router.navigate(['/mymedia/'])});
  }
message(){
  alert("you have uploaded the media & redirecting you to mymedia")
}
    

  ngOnInit() {
  }

}
