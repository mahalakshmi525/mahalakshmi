import { Component, OnInit } from '@angular/core';
//import { AuthenticationService } from 'src/app/services/authentication.service';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { UserAuthService } from 'src/app/services/user-auth.service';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';
import { Router } from '@angular/router';
import { SearchedUser } from 'src/app/model/searcheduser.model';
import { SearchedUserlList } from 'src/app/model/searcheduserlist.model';

@Component({
  selector: 'app-search',
 templateUrl: './search.component.html',
  //styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
 
  searchtext : string;
  myFormGroup : FormGroup;
  result : string ;
  userList : Array<SearchedUser>;
  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }

  constructor(public auth:UserAuthService,formBuilder : FormBuilder,public router: Router) { 
    this.myFormGroup=formBuilder.group({
     
      "search":new FormControl(""),
      
     });
  }
  search(){
    this.search= this.myFormGroup.controls['search'].value;
    this.auth.getSearchedUsers(this.searchtext).subscribe(
      (response : SearchedUserlList) => {
        this.userList = response.userList;
        this.userList = this.userList.map(user =>{
          user.profileUrl = "http://localhost:8765/user-service/"+user.profileUrl;
          return user;
        });
        
      }
    );
    
    
}


  
}
