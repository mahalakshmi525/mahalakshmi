package com.cts.training.users.exception;

public class UsersNotFoundException extends RuntimeException{

	public UsersNotFoundException(String message) {
		
		super(message);
	}
}
