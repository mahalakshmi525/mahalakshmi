package com.cts.training.users.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.users.entity.Users;
import com.cts.training.users.repository.UsersRepository;


@Service
public class UserServiceImpl {
	
	
		@Autowired
		private UsersRepository usersRepository;
		
		public List<Users> findAllUsers() {
			
			return this.usersRepository.findAll();
		}
		
		public Users findUsersById(Integer id) {
			// TODO Auto-generated method stub
			
			Optional<Users> record =  this.usersRepository.findById(id);
			
			Users users = new Users();
			if(record.isPresent())
				users = record.get();
			return users;
			
		}

		public boolean addUser(Users users) {
			// TODO Auto-generated method stub
			this.usersRepository.save(users);
			return true;
		}

		public boolean updateUsers(Users users) {
			// TODO Auto-generated method stub
			this.usersRepository.save(users);
			return true;
		}

		public boolean deleteUsers(Integer id) {
			// TODO Auto-generated method stub
			this.usersRepository.deleteById(id);
			return true;
		}

}
