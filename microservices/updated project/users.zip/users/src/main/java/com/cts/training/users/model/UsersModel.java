package com.cts.training.users.model;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UsersModel {
	
	     
		private String username;
		private String firstname;
		private String lastname;
		private String email;
		private String password;
		private LocalDate dob;
		

	

}
