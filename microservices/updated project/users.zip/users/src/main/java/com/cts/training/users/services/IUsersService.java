package com.cts.training.users.services;

import java.util.List;

import com.cts.training.users.entity.Users;

public interface IUsersService {
	List<Users> findAllUsers();
	Users findUserById(Integer id);
	boolean addUser(Users users);
	boolean updateUser(Users users);
	boolean deleteUser(Integer id);

}
