import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  errorMessage : string;
  autherized : boolean;

  constructor(public auth : AuthenticationService, public router : Router) { 
      this.errorMessage = "Invalid Credentials!!!";
      this.autherized = true;
  }

  

  checkLogin(txtLogin : HTMLInputElement, txtPass : HTMLInputElement){

    this.auth.authenticate(txtLogin.value, txtPass.value).subscribe(

      successData=>{
        console.log("SUCCESS...");
        console.log(successData);
        this.autherized = true;
        this.router.navigate(['/product']);
      },
     
      failureData => {
        console.log("FAILED!!!");
        this.autherized = false;
      }
    );
  }

  ngOnInit() {
  }

}
