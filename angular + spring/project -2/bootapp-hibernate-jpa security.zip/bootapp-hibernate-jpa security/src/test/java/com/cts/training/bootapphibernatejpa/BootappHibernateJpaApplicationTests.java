package com.cts.training.bootapphibernatejpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootappHibernateJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
