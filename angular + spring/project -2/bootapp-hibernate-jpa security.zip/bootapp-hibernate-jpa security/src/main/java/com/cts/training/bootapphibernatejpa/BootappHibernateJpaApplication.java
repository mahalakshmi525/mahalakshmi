package com.cts.training.bootapphibernatejpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootappHibernateJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootappHibernateJpaApplication.class, args);
	}

}
