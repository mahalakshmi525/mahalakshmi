package com.cts.training.bootapphibernatejpa.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class security extends AbstractSecurityWebApplicationInitializer {
     
}
