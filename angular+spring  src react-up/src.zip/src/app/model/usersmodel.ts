import { first } from 'rxjs/operators';


export class Users{
    id:number;
    username:String;
    password:String;
    email : String;
    firstname:String;
    lastname : String;
    dob:number;
    

    constructor(id:number,username:string,password:string,email:string,firstname:string,lastname:string,dob:number){
    this.id = id;
    this.username = username;
    this.password = password;
    this.email=email;
    this.firstname=firstname;
    this.lastname=lastname;
    this.dob=dob;
    
    }
    
}