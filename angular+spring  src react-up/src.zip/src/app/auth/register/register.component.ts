import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  //styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  //ngOnInit(): void {
    //throw new Error("Method not implemented.");
  //}
  username : string;
  password: string;
  errorMessage: string;
  autherized: boolean;
  myFormGroup : FormGroup;
  myRegisterName : FormControl;
  repeatpassword: String;

  constructor(public router:Router) { }
  checkLogin(txtLogin : HTMLInputElement, txtPass : HTMLInputElement,txtrepeatPass:HTMLInputElement){
    this.router.navigate(['/login']);
  }
  register(){
    this.username= this.myFormGroup.controls['username'].value;
      this.password=this.myFormGroup.controls['password'].value;
      this.repeatpassword=this.myFormGroup.controls['repeatpassword'].value;
    
     }

  ngOnInit() : void {
  }
}

