import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-search',
 templateUrl: './search.component.html',
  //styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  myFormGroup: FormGroup;
  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }

  constructor(public auth:AuthenticationService) { }
  search(){
    this.search= this.myFormGroup.controls['search'].value;
    
    
}


  
}
