import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-multimedia',
  templateUrl: './multimedia.component.html',
  //styleUrls: ['./multimedia.component.css']
})
export class MultimediaComponent implements OnInit {
  title: String;
  description: String;
  tags : String;
  myFormGroup : FormGroup;
 

  constructor() { }
  multimedia(){
      this.title= this.myFormGroup.controls['Title'].value;
      this.description=this.myFormGroup.controls['Description'].value;
      this.tags=this.myFormGroup.controls['Tags'].value;
      
  }

  ngOnInit() {
  }

}
