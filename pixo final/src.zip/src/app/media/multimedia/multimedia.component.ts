import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-multimedia',
  templateUrl: './multimedia.component.html',
  //styleUrls: ['./multimedia.component.css']
})
export class MultimediaComponent implements OnInit {
  title: String;
  description: String;
  tags : String;
  myFormGroup : FormGroup;
   
  public imagePath;
  imgURL: any;
  public message: string;

  selectedFiles: FileList;
  currentFileUpload: File;


  constructor(formBuilder : FormBuilder) {
    this.myFormGroup=formBuilder.group({
     
      "title":new FormControl(""),
      "description": new FormControl(""),
      "tags":new FormControl("")
        
     });
   }
   selectFile(event) {
    this.selectedFiles = event.target.files;
    this.preview(this.selectedFiles);
  }
  preview(files){
    if (files.length === 0)
      return;
  
      // loop around to work on all files
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }
  }
  multimedia(){
      this.title= this.myFormGroup.controls['Title'].value;
      this.description=this.myFormGroup.controls['Description'].value;
      this.tags=this.myFormGroup.controls['Tags'].value;
      
  }

  ngOnInit() {
  }

}
