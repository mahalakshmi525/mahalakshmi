import { Component, OnInit } from '@angular/core';
import { Media } from 'src/app/model/media.model';
import { MediaserviceService } from 'src/app/services/mediaservice/mediaservice.service';
import { Router } from '@angular/router';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';

@Component({
  selector: 'app-mymedia',
  templateUrl: './mymedia.component.html',
  //styleUrls: ['./mymedia.component.css']
})
export class MymediaComponent implements OnInit {

  medialist : Array<Media>;
  constructor(public mediaService : MediaserviceService , public router  : Router , public auth : UserserviceService) { }

  

  ngOnInit() {
    this.mediaService.getAllMedia().subscribe((responce : Media)=>{
      this.medialist=responce.filelist.map(media => {
        media.url = "http://localhost:8765/media-service/" + media.url;
        return media;
      });
      console.log(this.medialist)
    });
    
  }
}
