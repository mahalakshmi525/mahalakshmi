package com.cts.training.media.Controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.media.Repository.MediaRepository;
import com.cts.training.media.entity.Media;
import com.cts.training.media.exception.MediaErrorResponse;
import com.cts.training.media.exception.MediaNotFoundException;
import com.cts.training.media.model.MediaData;
import com.cts.training.media.model.MediaModel;
import com.cts.training.media.model.MediaUploadModel;
import com.cts.training.media.services.IMediaService;
import com.cts.training.media.services.StorageService;


@RestController
public class MediaController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private IMediaService mediaService;
	
	@Autowired
	private StorageService storageService;
	
	// @RequestMapping(value =  "/products", method = {RequestMethod.GET, RequestMethod.PUT} )
	@GetMapping("/media") 
	public ResponseEntity<MediaModel> getall() {
		MediaModel medialist=new MediaModel();
		medialist.setMedialist(this.mediaService.getall());
		ResponseEntity<MediaModel> response = 
								new ResponseEntity<MediaModel>(medialist, HttpStatus.OK);
		
		
		return response;
	}
	
	// {<data variable>}
	@GetMapping("/media/{mediaId}") // GET HTTP VERB
	public ResponseEntity<MediaData> getById(@PathVariable Integer mediaId) {
		
		MediaData data=new MediaData();
		Media record=new Media();
		Optional<Media> media=this.mediaService.getWithId(mediaId);
		if(media.isPresent())
			record = media.get();
		else {
			throw new MediaNotFoundException("Media Not Found");
		}
	
	data.setId(record.getId());
	data.setUserId(record.getUserId());
	data.setTitle(record.getTitle());
	data.setTags(record.getTags());
	data.setDescription(record.getDescription());
	data.setType(record.getMimetype());
	data.setFile(record.getFileurl());
	ResponseEntity<MediaData> response = new ResponseEntity<MediaData>(data, HttpStatus.OK);
	return response;
  }
	
	
	
	// @RequestMapping(value =  "/products", method = RequestMethod.POST)

	@PostMapping(value = "/media", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public boolean save(MultipartFile file) {
		this.storageService.store(file);
		return true;
	}
	
	// for saving media info in db
	@PostMapping(value = "/media")
	public boolean saveData(@RequestBody MediaUploadModel media) {
		MediaData mediamod = new MediaData();
		mediamod.setTitle(media.getTitle());
		mediamod.setDescription(media.getDescription());
		mediamod.setTags(media.getTags());
		mediamod.setUserId(media.getUserId());
		mediamod.setFile(media.getUrl());
		mediamod.setType(media.getType());
		this.mediaService.save(mediamod);
		//this.storageService.store(file);
		return true;
	}
	
	@PutMapping("/media")
	public boolean update(@RequestBody MediaData user) {
		
		this.mediaService.updateuser(user);
		return true;
		
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<MediaErrorResponse> productOperationErrorHAndler(Exception ex) {
		// create error object
		MediaErrorResponse error = new MediaErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<MediaErrorResponse> response =
										new ResponseEntity<MediaErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}
}
