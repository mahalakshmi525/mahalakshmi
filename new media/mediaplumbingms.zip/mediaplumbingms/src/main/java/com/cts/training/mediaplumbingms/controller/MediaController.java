package com.cts.training.mediaplumbingms.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.cts.training.mediaplumbingms.feignproxy.MediaServiceProxy;
import com.cts.training.mediaplumbingms.model.MediaModel;

@RestController
public class MediaController {

	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private MediaServiceProxy mediaProxy;
	
	
	private final String MEDIA_URL = "http://localhost:7004/media-service/media";
	
	@PostMapping("/media")
	public void post(@RequestParam("file") MultipartFile file,@RequestParam("url") String url,@RequestParam("title") String title,
			@RequestParam("description") String description,@RequestParam("tags") String tags,@RequestParam("userid") String userid,
			@RequestParam("type") String type) {
		logger.info("title : "+title);
		logger.info("userid: "+userid);
		logger.info("url : "+url);
		logger.info("desc : "+description);
		logger.info("tags : "+tags );
		logger.info("type : "+type);
		
		logger.info(file.getOriginalFilename() + " : "  +file.getSize());
		
		// create a model using other info
		MediaModel model = new MediaModel(Integer.parseInt(userid),url,title,description,tags,type);
		
		//this.restTemplate.getForObject(MEDIA_URL, MediaDataModel.class);
		// 1. call media microservice to save data in db
		this.mediaProxy.saveData(model);
		
		// 2. call media microservice to upload file
		this.mediaProxy.save(file);//,model);
		
		
		
	}
	
}
