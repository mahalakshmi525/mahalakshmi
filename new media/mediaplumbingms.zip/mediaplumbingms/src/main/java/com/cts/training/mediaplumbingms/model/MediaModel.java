package com.cts.training.mediaplumbingms.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class MediaModel {
	private Integer userid;
	private String url;
	private String title;
	private String description;
	private String tags;
	private String type;

}
