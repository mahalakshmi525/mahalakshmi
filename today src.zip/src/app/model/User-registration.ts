export class UserRegistrationDetails{
     
  id(id: any): string {
     throw new Error("Method not implemented.");
   }
      username :string;
      firstname:string;
      lastname:string;
     password : string;
      rePassword : string; 
      email : string;
      profile:string;
     
     constructor(username:string,firstname:string,lastname:string, password : string,rePassword : string, email:string,profile:string){
     this.username=username;
     this.firstname=firstname;
     this.lastname=lastname;
      this.password=password; 
      this.rePassword=rePassword; 
      this.email=email;
      this.profile=profile;
     
     }
   
    }
    