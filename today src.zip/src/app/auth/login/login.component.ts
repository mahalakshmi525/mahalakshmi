import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { AuthenticationService } from 'src/app/services/authentication.service';
import{FormGroup, FormControl, FormBuilder, Validators} from'@angular/forms';
import { UserRegistrationDetails } from 'src/app/model/User-registration';
import { UserAuthserviceService } from 'src/app/services/user-authservice.service';
import { UserserviceService } from 'src/app/services/userservice.service';
import { RegistrationService } from 'src/app/services/registrationservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  //styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username:string;
password:string;
autherized: boolean;
 errorMessage: string;
 myFormGroup : FormGroup;
 details:Array<UserRegistrationDetails>;

  submitted: boolean;
  constructor(public auth:UserAuthserviceService,public router : Router, public ser:UserserviceService ,formBuilder: FormBuilder,public userdetails :RegistrationService) {
    this.errorMessage = "Invalid Credentials!!!";
    this.autherized = true;
    console.log("in form bilder of login");
    this.myFormGroup=formBuilder.group({
     
    "username":new FormControl(""),
        "password": new FormControl("")
   });
  }
  get f(){
    return this.myFormGroup.controls;
  }
  login(){
    console.log("login method");
    this.username= this.myFormGroup.controls['username'].value;
    this.password=this.myFormGroup.controls['password'].value;
    this.submitted = true;
    this.auth.authenticate(this.username, this.password).subscribe(
      // success function
      successData=>{
        console.log("SUCCESS...");
        console.log(successData);
        this.autherized = true;
        this.router.navigate(['/media']);
      },
      // failure function
      failureData => {
        console.log("FAILED!!!");
        this.autherized = false;
      }
    );
  console.log(this.auth.authenticate(this.username,this.password));
   console.log("Username : "+this.username+"\n"+"Password : "+this.password);
   }


    ngOnInit() {
    }
  
  }

