import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserRegistrationDetails } from 'src/app/model/User-registration';
import { RegistrationService } from 'src/app/services/registrationservice.service';
import { UserserviceService } from 'src/app/services/userservice.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  //styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  [x: string]: any;
  //ngOnInit(): void {
    //throw new Error("Method not implemented.");
  //}
 
  myFormGroup : FormGroup;
  myRegisterName : FormControl;
  email: string;
  route:any;
  username: string;
  repeatpassword: string;
  sucesstxt: string;
  errtext: string;
  submitted: boolean=false;
  firstname: any;
  profile: any;
  lastname: any;
  password: any;
  userlist : Array<UserRegistrationDetails>;

  constructor(public details : RegistrationService,public router : Router, formBuilder: FormBuilder,public ser : UserserviceService) {
    console.log("in form bilder of reg");
    this.myFormGroup=formBuilder.group({
      "firstname" : new FormControl(""),
      "lastname" : new FormControl(""),
      "username" : new FormControl(""),
      "email" : new FormControl(""),
      "password" : new FormControl(""),
      "repeatpassword" : new FormControl(""),
      "profile" : new FormControl("")
    });

  }
  
  get f(){
    return this.myFormGroup.controls;
  }
  checkUsername(){
    console.log("hii check");
    this.username=this.myFormGroup.controls["username"].value;
    for( let u of this.userlist)
    {
      if(this.username=name){
        this.errormessage="Already Exist";
      }
      else{
        this.errormessage="success";
      }
    }
    
  }
  
  reg(){
    console.log("Registration method");
    this.submitted = true;
    if(this.myFormGroup.valid){
    this.firstname = this.myFormGroup.controls['firstname'].value;
    this.lastname = this.myFormGroup.controls['lastname'].value;
    this.profile =  this.myFormGroup.controls['profile'].value;
    this.password=this.myFormGroup.controls['password'].value;
    console.log(this.password);
    this.repeatpassword=this.myFormGroup.controls['repeatpassword'].value;
    this.username=this.myFormGroup.controls['username'].value;
    this.email=this.myFormGroup.controls['email'].value;
   
    //saving into database
    let creatuser=new UserRegistrationDetails(this.firstname,this.lastname,this.username,this.email,this.password,this.repeatpassword,this.profile);
    this.ser.addUser(creatuser).subscribe((responce:any)=>{alert("Account created successfully....");this.router.navigate(['/login']);});
   
   }else{
     return alert("Please enter valid details..")
   }
  
}
/*validateUserName(uname:HTMLInputElement){
  if(uname.value=="First"){
    alert("UserName taken");
  }
  else if(uname.value.length==0){
    alert("please enter username first");
  }
  else{
    this.validate=true;
    this.avilable="Username Available"
  }
}*/

  ngOnInit() {
    this.ser.getAllUsers().subscribe((response:any)=>{this.userlist=response;console.log(response)});
  }

}
