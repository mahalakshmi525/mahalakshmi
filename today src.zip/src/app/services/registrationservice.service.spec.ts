import { TestBed } from '@angular/core/testing';
import { RegistrationService } from './registrationservice.service';

//import { RegistrationService } from './registrationservice.service';

describe('RegistrationserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RegistrationService = TestBed.get(RegistrationService);
    expect(service).toBeTruthy();
  });
});
