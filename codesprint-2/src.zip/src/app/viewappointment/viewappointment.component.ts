import { Component, OnInit } from '@angular/core';
import { User } from '../models/appointment.model';
import { UserService } from '../services/user.service';

@Component({
  selector: 'viewappointment',
  templateUrl: './viewappointment.component.html',
  styleUrls: ['./viewappointment.component.css']
})
export class ViewappointmentComponent implements OnInit {

  appointments:Array<User>
  

  constructor(public userService:UserService ) { }


  ngOnInit() {
   
      this.userService.getAppointments().subscribe(data => {
        this.appointments = data;})
    }
  

}
