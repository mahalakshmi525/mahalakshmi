import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    setTimeout(function(){ document.getElementById('bha').innerHTML="Success usually comes to those who are too busy to be looking for it..."}, 1000);
    setTimeout(function(){ document.getElementById('bha').innerHTML="All progress takes place outside the comfort zone..."}, 2000);
    setTimeout(function(){ document.getElementById('bha').innerHTML="If you think lifting is dangerous,try being weak.Being weak is dangerous..."}, 3000);
    setTimeout(function(){ document.getElementById('bha').innerHTML="Action is the fundamental key to all Success..."}, 4000);
  }

}
