package com.project.pixogram.users.model;

public class ResponseData {
	private String message;
	private Long timeStamp;
	private Integer userId;
	
	
	
	public ResponseData(String message, Long timeStamp, Integer id) {
		
		this.message = message;
		this.timeStamp = timeStamp;
		this.userId = id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
	
	
}
