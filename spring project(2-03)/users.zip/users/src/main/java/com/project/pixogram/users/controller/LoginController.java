package com.project.pixogram.users.controller;


import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.pixogram.users.entity.Users;
import com.project.pixogram.users.model.ResponseData;
import com.project.pixogram.users.model.UsersModel;
import com.project.pixogram.users.repository.UsersRepository;
import com.project.pixogram.users.service.IUsersService;


@RestController
//@CrossOrigin("http://localhost:4200")
@CrossOrigin(origins = "http://localhost:4200", allowedHeaders="*")
public class LoginController {

	@Autowired
	private IUsersService usersService;
	
	@Autowired
	private UsersRepository usersRepository;
	
		private Logger logger = LoggerFactory.getLogger(this.getClass());
		// testing end-point
		
		@GetMapping("/login")
		public ResponseEntity<ResponseData> login(HttpServletRequest request) {
			
			String authorization = request.getHeader("Authorization");
			String[] values = null;
			
			if (authorization != null && authorization.startsWith("Basic")) {
			    // Authorization: Basic base64credentials
			    String base64Credentials = authorization.substring("Basic".length()).trim();
			    byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
			    String credentials = new String(credDecoded, StandardCharsets.UTF_8);
			    // credentials = username:password
			    values = credentials.split(":", 2);
			}
			
			
			logger.info("Logged In...");
			logger.info(values[0]);
			logger.info(values[1]);
	        
	        Users users = this.usersRepository.findByUsername(values[0]).get(0);
	        logger.info("User : " + users);
	        // add any additional information like firstname, lastname, profilepic etc
			ResponseData data = new ResponseData("Welcome!!!", System.currentTimeMillis(), users.getId());

			ResponseEntity<ResponseData> response = 
						new ResponseEntity<ResponseData>(data, HttpStatus.OK);
			
			return response;
			
		}
			
		
		@PostMapping("/register")
		public ResponseEntity<ResponseData> register(@RequestBody UsersModel usersModel) {
			// if called then credentials are valid
			logger.info("Registration...");
			logger.info("User Input : " + usersModel);
			this.usersService.saveuser(usersModel);
			
			ResponseData data = new ResponseData("Welcome!!!", System.currentTimeMillis(), usersModel.getId());

			ResponseEntity<ResponseData> response = 
                                           new ResponseEntity<ResponseData>(data, HttpStatus.OK);
			return response;

	}
		
		
}
