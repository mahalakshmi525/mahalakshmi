import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';

@Component({
  selector: 'app-singlemedia',
  templateUrl: './singlemedia.component.html',
  //styleUrls: ['./singlemedia.component.css']
})
export class SinglemediaComponent implements OnInit {
  description: String;
  myFormGroup: FormGroup;
  title: String;
  tags: String;

  constructor(formBuilder : FormBuilder) { 
    this.myFormGroup=formBuilder.group({
     
      "title":new FormControl(""),
      "description": new FormControl(""),
      "tags":new FormControl("")
        
     });
  }
  singlemedia(){
    this.title= this.myFormGroup.controls['Title'].value;
    this.description=this.myFormGroup.controls['Description'].value;
    this.tags=this.myFormGroup.controls['Tags'].value;
    
}

  ngOnInit() {
  }

}
