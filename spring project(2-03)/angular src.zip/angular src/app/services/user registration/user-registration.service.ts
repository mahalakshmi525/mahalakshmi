import { Injectable } from '@angular/core';
import{ HttpClient} from '@angular/common/http';
import { UserRegistrationDetails } from 'src/app/model/User-registration';




const REG_URL = "http://localhost:8765/users-service/register";
const API_URL = "http://localhost:8765/users-service/users";

@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {


  constructor(public http : HttpClient) { 

  }

  getAllUsers(){
    
    return this.http.get(API_URL);
  }

  
  addNewUser(User : UserRegistrationDetails){
    
    return this.http.post(REG_URL,User );
  }

  // methid to get single record of given id
  getOneUser(id:number){
    // GET http verb
    return this.http.get(API_URL + "/" + id);

  }

  // method to send updated object(product) to server
  updateUser(id:number, user : UserRegistrationDetails){
    // PUT http verb
    return this.http.put(API_URL + "/" + id, user);
  }

  // method to delete single record of given id
  deleteUser(id:number){
    // DELETE http verb
    return this.http.delete(API_URL + "/" + id);

  }

}


  

