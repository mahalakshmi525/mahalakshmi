import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { Router } from '@angular/router';
import { UserAuthService } from 'src/app/services/user-auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  //styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  profile : string;
  username:string;

  constructor(public auth:AuthenticationService,public authe:UserAuthService) { 
    this.profile="http://localhost:8765/user-service/"+this.authe.getPic(); 
    this.username+this.authe.getUserDetails();
  }

  ngOnInit() {
  }

}
