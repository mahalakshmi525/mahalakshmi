import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserRegistrationDetails } from 'src/app/model/user-registration';
const API_URL = "http://localhost:8765/user-service/users";
const REG_URL = "http://localhost:8765/user-service/register";
@Injectable({
  providedIn: 'root'
})


export class UserserviceService {

  constructor(public http : HttpClient) {


   }

  getAllUsers():any{
    return this.http.get(API_URL);
  }

  getUser(id:number):any{
    return this.http.get(API_URL+"/"+id);
  }

  addUser(user:UserRegistrationDetails):any{
    return this.http.post(REG_URL,user);
  }

  delete(id:number){
    this.http.delete(API_URL+"/"+id);
  }

  update(id:number,user:UserRegistrationDetails):any{
    return this.http.put(API_URL+"/"+id,user);
  }
}
