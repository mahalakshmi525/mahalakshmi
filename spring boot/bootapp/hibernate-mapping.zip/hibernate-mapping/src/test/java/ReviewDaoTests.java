import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cts.training.hibernatemapping.HibernateMappingApplication;
import com.cts.training.hibernatemapping.dao.CourseDao;
import com.cts.training.hibernatemapping.dao.ReviewDao;
import com.cts.training.hibernatemapping.entity.Course;
import com.cts.training.hibernatemapping.entity.Review;


@RunWith(SpringRunner.class) // Test Runner
@SpringBootTest(classes =  HibernateMappingApplication.class )
class ReviewDaoTests {
	@Autowired
	private CourseDao courseDao;
	
	@Autowired
	private ReviewDao reviewDao;

	@Test
	void testaddReviewAndCourse() {
		
		
	   		
		Course course = new Course();
		course.setName("angular");
		
		List<Review> reviews = new ArrayList<Review>();
		

		Review review1 = new Review();
		review1.setReview("Excellent");		
		reviews.add(review1);
		Review review2 = new Review();
		review2.setReview("Good for future use");
		Review review3 = new Review();
		reviews.add(review2);
		
		
		
		 Review added = this.reviewDao.addReviewAndCourse(reviews, course);
			assertEquals("angular", added.getReview());

		
	}
	@Test
	void testaddReviewtoExistingCourse(){
		
		Course course =this.courseDao.findById(2);
		
		Review review1 = new Review();
		review1.setReview("testExcellent");
		
		
	    Review added = this.reviewDao.addReviewtoExistingCourse( review1,course);
		assertEquals("testExcellent", added.getReview());
		
	}
	
	
}
