
export class Userid {
         id : number;
		 firstname :string;
		 lastname :string;
		 profile :any;
     constructor(id,firstname,lastname,profile){
        
         
         this.id = id ;
         this.firstname = firstname;
         this.lastname = lastname;
         this.profile = profile;
     }
}