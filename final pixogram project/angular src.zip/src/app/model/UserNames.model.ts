
export class UserName {

	userlist : Array<UserName>;
}