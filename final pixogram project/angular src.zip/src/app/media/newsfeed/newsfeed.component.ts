import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/services/user-auth.service';
import { NewsFeed } from 'src/app/model/NewsFeed.model';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';
import { Userid } from 'src/app/model/Userid.model';
//import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-newsfeed',
  templateUrl: './newsfeed.component.html',
  styleUrls: ['./newsfeed.component.css']
})
export class NewsfeedComponent implements OnInit {
 
  userId : string;
  feeds:NewsFeed[];

  constructor( public auth:UserAuthService, public userservice:UserserviceService) {
  }

  ngOnInit() {
    this.userId=this.auth.getId();
    this.userservice.getAllFeed(this.userId).subscribe(data=>{
      this.feeds=data;
    })
  }

}

  
