import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mediadetails',
  templateUrl: './mediadetails.component.html',
  styleUrls: ['./mediadetails.component.css']
})
export class MediadetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
