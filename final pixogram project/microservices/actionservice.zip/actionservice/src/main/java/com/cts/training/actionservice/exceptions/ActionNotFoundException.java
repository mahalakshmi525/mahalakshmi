package com.cts.training.actionservice.exceptions;

public class ActionNotFoundException extends RuntimeException {
		public ActionNotFoundException(String message) {
			// TODO Auto-generated constructor stub
			super(message);
		}
}
