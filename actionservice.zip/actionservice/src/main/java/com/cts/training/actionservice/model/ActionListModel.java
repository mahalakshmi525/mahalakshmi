
package com.cts.training.actionservice.model;

import java.util.List;

import com.cts.training.actionservice.entity.Action;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ActionListModel {
	
	List<Action> actions;
}
