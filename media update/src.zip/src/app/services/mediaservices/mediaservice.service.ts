import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';


const BasicURL = "http://localhost:3000/mediafiles";
@Injectable({
  providedIn: 'root'
})
export class MediaserviceService {
  baseUrl: string = 'http://localhost:8765/media-plumbing/media';
  constructor( public http:HttpClient) {

   }

   getAllMedia():any{
    return this.http.get(BasicURL);
  }

  getMedia(id:number):any{
    return this.http.get(BasicURL+"/"+id);
  }

  pushFileToStorage(file: File,title,description,tags,url,type) : Observable<HttpEvent<{}>>{
    
    const formdata: FormData = new FormData();

    // let product = new  Product (name,category,cost,file,url);
    formdata.append('file', file, url);
    formdata.append('title',title)
    formdata.append('description',description)
    formdata.append('type',type)
    console.log("userid  : "+sessionStorage.getItem("userid"))
    formdata.append('userid',sessionStorage.getItem("userid"))
    formdata.append("tags",tags)
    formdata.append('url',url)
    
    // header info to set for responding the progress report
    /*return this.http.post(this.baseUrl, formdata,{
      reportProgress: true,
      responseType: 'text'
    });*/



    const req = new HttpRequest('POST', `${this.baseUrl}`, formdata, {
      reportProgress: true,
      responseType: 'text'
    });

    return this.http.request(req);
  }
}
