package com.cts.training.mediaplumbingms.feignproxy;


import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.mediaplumbingms.model.MediaDataModel;



@FeignClient(name ="api-gateway", url="http://localhost:8765/")
@RibbonClient(name ="media-service")

public interface MediaServiceProxy {

	@PostMapping(value = "/media-service/media", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public boolean save(MultipartFile file);
	
	@PostMapping(value = "/media-service/mediadata")
	public boolean saveData(@RequestBody MediaDataModel media);
	

}
