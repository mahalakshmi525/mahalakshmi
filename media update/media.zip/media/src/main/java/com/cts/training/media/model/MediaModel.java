package com.cts.training.media.model;

import java.util.List;

import com.cts.training.media.entity.Media;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class MediaModel {
	
		
		private List<Media> medialist;
}
