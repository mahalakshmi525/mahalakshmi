package com.cts.training.media.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class MediaUploadModel implements Serializable {
	
	private Integer userId;
	private String title;
	private String description;
	private String tags;
	private String url;
	public String Type; 
}
