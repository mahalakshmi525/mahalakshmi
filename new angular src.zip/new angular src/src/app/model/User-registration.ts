export class UserRegistrationDetails{
    username:string;
    password:string;
    repassword:string;
    email:string;
constructor(username:string,
           password:string,
           repassword:string,
               email:string){
                   this.username=username;
                   this.password=password;
                   this.repassword=repassword;
                   this.email=email;

}

}