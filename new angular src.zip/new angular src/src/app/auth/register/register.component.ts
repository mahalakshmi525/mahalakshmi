import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/app/services/authentication.service';
//import { UserRegistrationDetails } from 'src/app/model/usersmodel';
import { UserRegistrationService } from 'src/app/services/user registration/user-registration.service';
import { UserRegistrationDetails } from 'src/app/model/User-registration';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  //styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  //ngOnInit(): void {
    //throw new Error("Method not implemented.");
  //}
 
  myFormGroup : FormGroup;
  myRegisterName : FormControl;
  email: string;
  route:any;
  user: string;
  repass: string;
  pass: string;
  sucesstxt: string;
  errtext: string;

  constructor(public router:Router,formBuilder: FormBuilder,public details:UserRegistrationService) { 
    this.myFormGroup=formBuilder.group({
     
      "username":new FormControl(""),
      "password": new FormControl(""),
      "repeatpassword":new FormControl(""),
      "email":new FormControl("")
        
     });
    }
  reg(){
    this.user= this.myFormGroup.controls['username'].value;
      this.pass=this.myFormGroup.controls['password'].value;
      this.repass=this.myFormGroup.controls['repeatpassword'].value;
      this.email=this.myFormGroup.controls['email'].value;

      this.route.navigate(['/login']);
     
     let details=new UserRegistrationDetails(this.user,this.pass,this.repass,this.email);

  this.details.addNewUser(details).subscribe((response)=> console.log(response));
  
  
  console.log("username :" +this.user+"\n" + "email :" +this.email+"\n"+ "password :"+this.pass+"\n"+ "repassword :"+this.repass+"\n");
  if (this.pass === this.repass){    
  this.sucesstxt = "registerd successfully";
       this.errtext="";
       
  
     }
     else{
      this.errtext = "Password not matched";
     this.sucesstxt="";
     }

      
  }

  ngOnInit() { 
 
  }
}

 