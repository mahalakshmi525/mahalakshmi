package com.project.pixogram.users.repository;

import org.springframework.stereotype.Repository;

import com.project.pixogram.users.entity.Authorities;

@Repository
public interface AuthorityRepository {
 
	public void save(Authorities authorities);
}
