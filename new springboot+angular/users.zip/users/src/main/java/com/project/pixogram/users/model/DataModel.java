package com.project.pixogram.users.model;

import java.util.List;

import com.project.pixogram.users.entity.Users;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataModel {

	public List<Users> users;
}
