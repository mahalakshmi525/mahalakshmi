import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-accountupdate',
  templateUrl: './accountupdate.component.html',
//styleUrls: ['./accountupdate.component.css']
})
export class AccountupdateComponent implements OnInit {
  myFormGroup:FormGroup;
  username: string;
  password: string;
  email: string;
  repeatpassword: string;

  constructor(public auth:AuthenticationService,formBuilder : FormBuilder) { 
    this.myFormGroup=formBuilder.group({
     
      "username":new FormControl(""),
      "password":new FormControl(""),
      "repeatpassword":new FormControl(""),
      "email":new FormControl("")
    
      
        
     });
  }
  update(){
    this.username= this.myFormGroup.controls['username'].value;
    this.password= this.myFormGroup.controls['password'].value;
    this.repeatpassword= this.myFormGroup.controls['repeatpassword'].value;
    this.email= this.myFormGroup.controls['email'].value;
    
    
     }
  ngOnInit() {
  }

}
